package br.acre.fapac.dto;

public class RendimentoDTO {
	private int idRendimento;
	private String nome;
	private String descricao;
	public int getIdRendimento() {
		return idRendimento;
	}
	public void setIdRendimento(int idRendimento) {
		this.idRendimento = idRendimento;
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public String getDescricao() {
		return descricao;
	}
	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}
}
