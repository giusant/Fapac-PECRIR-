package br.acre.fapac.dto;


public class BolsistaDTO {
	private int idBolsista;
	private String nome;
	private String cpf;
	private int tipoRendimento;
	private double auxilio;
	private double auxilioAnt;
	private double bolsa;
	private double bolsaAnt;
	private double diaria;
	private double diariaAnt;
	private String senha;
	private int ano;

	public String getSenha() {
		return senha;
	}
	public void setSenha(String senha) {
		this.senha = senha;
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public int getTipoRendimento() {
		return tipoRendimento;
	}
	public void setTipoRendimento(int tipoRendimento) {
		this.tipoRendimento = tipoRendimento;
	}
	public double getAuxilio() {
		return auxilio;
	}
	public void setAuxilio(double auxilio) {
		this.auxilio = auxilio;
	}
	public double getAuxilioAnt() {
		return auxilioAnt;
	}
	public void setAuxilioAnt(double auxilioAnt) {
		this.auxilioAnt = auxilioAnt;
	}
	public double getBolsa() {
		return bolsa;
	}
	public void setBolsa(double bolsa) {
		this.bolsa = bolsa;
	}
	public double getBolsaAnt() {
		return bolsaAnt;
	}
	public void setBolsaAnt(double bolsaAnt) {
		this.bolsaAnt = bolsaAnt;
	}
	public double getDiaria() {
		return diaria;
	}
	public void setDiaria(double diaria) {
		this.diaria = diaria;
	}
	public double getDiariaAnt() {
		return diariaAnt;
	}
	public void setDiariaAnt(double diariaAnt) {
		this.diariaAnt = diariaAnt;
	}
	public int getIdBolsista() {
		return idBolsista;
	}
	public void setIdBolsista(int idBolsista) {
		this.idBolsista = idBolsista;
	}
	public int getAno() {
		return ano;
	}
	public void setAno(int ano) {
		this.ano = ano;
	}
	public String getCpf() {
		return cpf;
	}
	public void setCpf(String cpf) {
		this.cpf = cpf;
	}

	
}
