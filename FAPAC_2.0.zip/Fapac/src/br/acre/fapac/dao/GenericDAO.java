package br.acre.fapac.dao;

import java.util.List;

import br.acre.fapac.exception.PersistenciaException;


public interface GenericDAO<T>{
void inserir(T obj) throws PersistenciaException;
	
	void atualizar(T obj)throws PersistenciaException;
	
	void deletar(Integer id)throws PersistenciaException;
	
	List<T> listarTodos()throws PersistenciaException;
	
	T buscarPorId(Integer id)throws PersistenciaException;
}
