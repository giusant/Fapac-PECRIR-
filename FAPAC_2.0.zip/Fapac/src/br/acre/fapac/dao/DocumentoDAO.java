package br.acre.fapac.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import br.acre.fapac.dto.DocumentoDTO;
import br.acre.fapac.exception.PersistenciaException;
import br.acre.fapac.jdbc.conexao.ConexaoUtil;



public class DocumentoDAO{

	
	public void inserir(DocumentoDTO documentoDTO) throws PersistenciaException {
		try{

			Connection connection =  ConexaoUtil.getInstance().getConnection();

			String sql ="INSERT INTO TB_DOCUMENTO(NOME_DOCUMENTO, DOCUMENTO, ANO "
					+ " )" + " VALUES(?,?,?)";

			PreparedStatement Statement = connection.prepareStatement(sql);

			Statement.setString(1, documentoDTO.getNomeDocumento());
			Statement.setObject(2, documentoDTO.getDocumento());
			Statement.setDate(3, new Date(documentoDTO.getAno().getTime()));
		
			
			Statement.execute();
			connection.close();
		}catch(Exception e){
			e.printStackTrace();
			throw new PersistenciaException(e.getMessage(),e ) ;
		}

	}

	
	public void atualizar(DocumentoDTO documentoDTO) throws PersistenciaException {
		try{
			Connection connection =  ConexaoUtil.getInstance().getConnection();
			
			String sql =  "UPDATE TB_DOCUMENTO " + "DOCUMENTO =? "+ "WHERE NOME = ?";
			
			PreparedStatement Statement = connection.prepareStatement(sql);
			Statement.setObject(1, documentoDTO.getDocumento());
			
			Statement.setString(2,documentoDTO.getNomeDocumento());
			
			Statement.execute();
			connection.close();
			
			
		}catch(Exception e){
			e.printStackTrace();
			throw new PersistenciaException(e.getMessage(), e);
		}

		
	}

	
	public void deletar(String nome) throws PersistenciaException {
		try{
			// trocar para long
			Connection connection = ConexaoUtil.getInstance().getConnection();
			String sql = "DELETE FROM TB_DOCUMENTO WHERE NOME_DOCUMENTO = ?";
			
			PreparedStatement Statement = connection.prepareStatement(sql);
			Statement.setString(1, nome);
			Statement.execute();
			connection.close();
		}catch(Exception e){
			e.printStackTrace();
			throw new PersistenciaException(e.getMessage(),e);
		}
		
		
	}

	public List<DocumentoDTO> listarTodos() throws PersistenciaException {
		List<DocumentoDTO> listaDocumentos = new ArrayList<DocumentoDTO>();
		try{
			Connection connection = ConexaoUtil.getInstance().getConnection();
			
			String sql = "SELECT * FROM TB_DOCUMENTO";
			
			 PreparedStatement statement = connection.prepareStatement(sql);
			 ResultSet resultSet = statement.executeQuery();
			 
			 while(resultSet.next()){ 
				 DocumentoDTO documentoDTO = new DocumentoDTO();
				 documentoDTO.setIdDocumento(resultSet.getInt("id_documento"));
				 documentoDTO.setNomeDocumento(resultSet.getString("nome_documento"));
				 documentoDTO.setDocumento(resultSet.getBytes("documento"));
				 documentoDTO.setAno(resultSet.getDate("ano"));
				
				
				 listaDocumentos.add(documentoDTO);
			 }
			 connection.close();

		}catch(Exception e){
			e.printStackTrace();
			throw new PersistenciaException(e.getMessage(), e);
		}
		return listaDocumentos;
	}


	public DocumentoDTO buscarPorCpf(String nome) throws PersistenciaException{
		DocumentoDTO documentoDTO = null;
		try{
			Connection connection = ConexaoUtil.getInstance().getConnection();

			String sql ="SELECT * FROM TB_DOCUMENTO WHERE NOME = ?";
			PreparedStatement statement =  connection.prepareStatement(sql);
			statement.setString(1, nome);
			ResultSet resultSet = statement.executeQuery();
			if(resultSet.next()){
				documentoDTO = new DocumentoDTO();
				documentoDTO.setIdDocumento(resultSet.getInt("id_documento"));
				documentoDTO.setNomeDocumento(resultSet.getString("nome_documento"));
				documentoDTO.setDocumento(resultSet.getBytes("documento"));
				documentoDTO.setAno(resultSet.getDate("ano"));
			}
			connection.close();
		}catch(Exception e){
			e.printStackTrace();
			throw new PersistenciaException(e.getMessage(), e);
		}
		return documentoDTO;
	}
}