package br.acre.fapac.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import br.acre.fapac.dto.BolsistaDTO;
import br.acre.fapac.dto.DocumentoDTO;
import br.acre.fapac.dto.RendimentoDTO;
import br.acre.fapac.exception.PersistenciaException;
import br.acre.fapac.jdbc.conexao.ConexaoUtil;


public class BolsistaDAO {

	SimpleDateFormat dateFormatAno = new SimpleDateFormat("yyyy");
	public void inserir(BolsistaDTO bolsistaDTO) throws PersistenciaException {
		try{
			
			Connection connection =  ConexaoUtil.getInstance().getConnection();
			
			String sql ="INSERT INTO TB_BOLSISTA(NOME, CPF, TIPO_RENDIMENTO, AUXILIO, AUXILIO_ANT, BOLSA, BOLSA_ANT, DIARIA, "
					+ "DIARIA_ANT, SENHA, ANO )" + " VALUES(?,?,?,?,?,?,?,?,?,?,?)";
			
			PreparedStatement Statement = connection.prepareStatement(sql);
			
			Statement.setString(1, bolsistaDTO.getNome());
			Statement.setString(2, bolsistaDTO.getCpf());
			Statement.setInt(3, bolsistaDTO.getTipoRendimento());
			Statement.setDouble(4, bolsistaDTO.getAuxilio());
			Statement.setDouble(5, bolsistaDTO.getAuxilioAnt());
			Statement.setDouble(6, bolsistaDTO.getBolsa());
			Statement.setDouble(7, bolsistaDTO.getBolsaAnt());
			Statement.setDouble(8, bolsistaDTO.getDiaria());
			Statement.setDouble(9, bolsistaDTO.getDiariaAnt());
			Statement.setString(10, bolsistaDTO.getSenha());
			Statement.setInt(11,bolsistaDTO.getAno() );
		
			
			
			Statement.execute();
			connection.close();
		}catch(Exception e){
			e.printStackTrace();
			throw new PersistenciaException(e.getMessage(),e ) ;
		}
	}

	
	public void atualizarPorCpf(BolsistaDTO bolsistaDTO) throws PersistenciaException {
		try{
			Connection connection =  ConexaoUtil.getInstance().getConnection();
			
			String sql =  "UPDATE TB_BOLSISTA " + "SET NOME =?," + "CPF =?,"  + "TIPO_RENDIMENTO =?," + "AUXILIO =?, "+ "AUXILIO_ANT =?, "+
					"BOLSA = ?, "+ "BOLSA_ANT =?, "+ "DIARIA =?, "+ "DIARIA_ANT =?, " +" ANO =? "+ "WHERE CPF = ? AND ANO =?";
			
			PreparedStatement Statement = connection.prepareStatement(sql);
			Statement.setString(1, bolsistaDTO.getNome());
			Statement.setString(2, bolsistaDTO.getCpf());
			Statement.setInt(3, bolsistaDTO.getTipoRendimento());
			Statement.setDouble(4,bolsistaDTO.getAuxilio());
			Statement.setDouble(5,bolsistaDTO.getAuxilioAnt());
			Statement.setDouble(6,bolsistaDTO.getBolsa());
			Statement.setDouble(7,bolsistaDTO.getBolsaAnt());
			Statement.setDouble(8,bolsistaDTO.getDiaria());
			Statement.setDouble(9,bolsistaDTO.getDiariaAnt());
			Statement.setInt(10, bolsistaDTO.getAno());
			
			Statement.setString(11,bolsistaDTO.getCpf());
			Statement.setInt(12, bolsistaDTO.getAno());
			
			Statement.execute();
			connection.close();
			
			
		}catch(Exception e){
			e.printStackTrace();
			throw new PersistenciaException(e.getMessage(), e);
		}
	}
	public void atualizar(BolsistaDTO bolsistaDTO) throws PersistenciaException {
		try{
			Connection connection =  ConexaoUtil.getInstance().getConnection();
			
			String sql =  "UPDATE TB_BOLSISTA " + "SET NOME =?," + "CPF =?,"  + "TIPO_RENDIMENTO =?," + "AUXILIO =?, "+ "AUXILIO_ANT =?, "+
					"BOLSA = ?, "+ "BOLSA_ANT =?, "+ "DIARIA =?, "+ "DIARIA_ANT =?, " +" ANO =?, "+" SENHA = ? "+ "WHERE ID_BOLSISTA =?";
			
			PreparedStatement Statement = connection.prepareStatement(sql);
			Statement.setString(1, bolsistaDTO.getNome());
			Statement.setString(2, bolsistaDTO.getCpf());
			Statement.setInt(3, bolsistaDTO.getTipoRendimento());
			Statement.setDouble(4,bolsistaDTO.getAuxilio());
			Statement.setDouble(5,bolsistaDTO.getAuxilioAnt());
			Statement.setDouble(6,bolsistaDTO.getBolsa());
			Statement.setDouble(7,bolsistaDTO.getBolsaAnt());
			Statement.setDouble(8,bolsistaDTO.getDiaria());
			Statement.setDouble(9,bolsistaDTO.getDiariaAnt());
			Statement.setInt(10, bolsistaDTO.getAno());
			Statement.setString(11, bolsistaDTO.getSenha());
			
			Statement.setInt(12,bolsistaDTO.getIdBolsista());
			
			
			Statement.execute();
			connection.close();
			
			
		}catch(Exception e){
			e.printStackTrace();
			throw new PersistenciaException(e.getMessage(), e);
		}
	}
	
	public void deletar(String cpf, int ano) throws PersistenciaException {
		try{
			//trocar para long
			Connection connection = ConexaoUtil.getInstance().getConnection();
			String sql = "DELETE FROM TB_BOLSISTA WHERE cpf = ? AND ano = ?";
			
			PreparedStatement Statement = connection.prepareStatement(sql);
			Statement.setString(1, cpf);
			Statement.setInt(2, ano);
			Statement.execute();
			connection.close();
		}catch(Exception e){
			e.printStackTrace();
			throw new PersistenciaException(e.getMessage(),e);
		}
		
	}
	public void deletartudo() throws PersistenciaException{
		try{
			Connection connection = ConexaoUtil.getInstance().getConnection();
			String sql = "DELETE FROM TB_BOLSISTA";
			
			PreparedStatement Statement = connection.prepareStatement(sql);
			Statement.execute();
			connection.close();
		}catch(Exception e){
			e.printStackTrace();
			throw new PersistenciaException(e.getMessage(),e);
		}
	}
	
	public List<BolsistaDTO> listarTodos() throws PersistenciaException {
		List<BolsistaDTO> listabolsistas = new ArrayList<BolsistaDTO>();
		try{
			Connection connection = ConexaoUtil.getInstance().getConnection();
			
			String sql = "SELECT * FROM TB_BOLSISTA";
			
			 PreparedStatement statement = connection.prepareStatement(sql);
			 ResultSet resultSet = statement.executeQuery();
			 
			 while(resultSet.next()){ 
				 BolsistaDTO bolsistaDTO = new BolsistaDTO();
				 bolsistaDTO.setIdBolsista(resultSet.getInt("id_bolsista"));
				 bolsistaDTO.setNome(resultSet.getString("nome"));
				 bolsistaDTO.setCpf(resultSet.getString("cpf"));
				 bolsistaDTO.setTipoRendimento(resultSet.getInt("tipo_rendimento"));
				 bolsistaDTO.setAuxilio(resultSet.getDouble("auxilio"));
				 bolsistaDTO.setAuxilioAnt(resultSet.getDouble("auxilio_ant"));
				 bolsistaDTO.setBolsa(resultSet.getDouble("bolsa"));
				 bolsistaDTO.setBolsaAnt(resultSet.getDouble("bolsa_ant"));
				 bolsistaDTO.setDiaria(resultSet.getDouble("diaria"));
				 bolsistaDTO.setDiariaAnt(resultSet.getDouble("diaria_ant"));
				 bolsistaDTO.setAno(resultSet.getInt("ano"));
				 bolsistaDTO.setSenha(resultSet.getString("senha"));
				 
				
				 listabolsistas.add(bolsistaDTO);
			 }
			 connection.close();

		}catch(Exception e){
			e.printStackTrace();
			throw new PersistenciaException(e.getMessage(), e);
		}
		return listabolsistas;
	}

	public BolsistaDTO buscarBolsistaPorCpfAno(String cpf, int ano) throws PersistenciaException {
		BolsistaDTO bolsistaDTO = null;
		try{
			Connection connection = ConexaoUtil.getInstance().getConnection();

			String sql ="SELECT * FROM TB_BOLSISTA WHERE CPF = ? AND ANO = ?";
			PreparedStatement statement =  connection.prepareStatement(sql);
			statement.setString(1, cpf);
			statement.setInt(2, ano);
			ResultSet resultSet = statement.executeQuery();
			if(resultSet.next()){
				 bolsistaDTO = new BolsistaDTO();
				 bolsistaDTO.setIdBolsista(resultSet.getInt("id_bolsista"));
				 bolsistaDTO.setNome(resultSet.getString("nome"));
				 bolsistaDTO.setCpf(resultSet.getString("cpf"));
				 bolsistaDTO.setTipoRendimento(resultSet.getInt("tipo_rendimento"));
				 bolsistaDTO.setAuxilio(resultSet.getDouble("auxilio"));
				 bolsistaDTO.setAuxilioAnt(resultSet.getDouble("auxilio_ant"));
				 bolsistaDTO.setBolsa(resultSet.getDouble("bolsa"));
				 bolsistaDTO.setBolsaAnt(resultSet.getDouble("bolsa_ant"));
				 bolsistaDTO.setDiaria(resultSet.getDouble("diaria"));
				 bolsistaDTO.setDiariaAnt(resultSet.getDouble("diaria_ant"));
				 bolsistaDTO.setAno(resultSet.getInt("ano"));
				 bolsistaDTO.setSenha(resultSet.getString("senha"));
			}
			connection.close();
		}catch(Exception e){
			e.printStackTrace();
			throw new PersistenciaException(e.getMessage(), e);
		}
		return bolsistaDTO;
	}
	public BolsistaDTO buscarBolsistaPorId( int id) throws PersistenciaException {
		BolsistaDTO bolsistaDTO = null;
		try{
			Connection connection = ConexaoUtil.getInstance().getConnection();

			String sql ="SELECT * FROM TB_BOLSISTA WHERE id_bolsista = ?";
			PreparedStatement statement =  connection.prepareStatement(sql);
			statement.setInt(1, id);
			ResultSet resultSet = statement.executeQuery();
			if(resultSet.next()){
				 bolsistaDTO = new BolsistaDTO();
				 bolsistaDTO.setIdBolsista(resultSet.getInt("id_bolsista"));
				 bolsistaDTO.setNome(resultSet.getString("nome"));
				 bolsistaDTO.setCpf(resultSet.getString("cpf"));
				 bolsistaDTO.setTipoRendimento(resultSet.getInt("tipo_rendimento"));
				 bolsistaDTO.setAuxilio(resultSet.getDouble("auxilio"));
				 bolsistaDTO.setAuxilioAnt(resultSet.getDouble("auxilio_ant"));
				 bolsistaDTO.setBolsa(resultSet.getDouble("bolsa"));
				 bolsistaDTO.setBolsaAnt(resultSet.getDouble("bolsa_ant"));
				 bolsistaDTO.setDiaria(resultSet.getDouble("diaria"));
				 bolsistaDTO.setDiariaAnt(resultSet.getDouble("diaria_ant"));
				 bolsistaDTO.setAno(resultSet.getInt("ano"));
				 bolsistaDTO.setSenha(resultSet.getString("senha"));
			}
			connection.close();
		}catch(Exception e){
			e.printStackTrace();
			throw new PersistenciaException(e.getMessage(), e);
		}
		return bolsistaDTO;
	}
	
	public RendimentoDTO buscarRendimento(Integer id ) throws PersistenciaException{
		RendimentoDTO rendimentoDTO = null;
		try{
			Connection connection = ConexaoUtil.getInstance().getConnection();

			String sql ="SELECT * FROM TB_RENDIMENTO WHERE ID_RENDIMENTO = ?";
			PreparedStatement statement =  connection.prepareStatement(sql);
			statement.setLong(1, id);
			ResultSet resultSet = statement.executeQuery();
			if(resultSet.next()){
				rendimentoDTO = new RendimentoDTO();
				rendimentoDTO.setIdRendimento(resultSet.getInt(1));
				rendimentoDTO.setNome(resultSet.getString(2));
				rendimentoDTO.setDescricao(resultSet.getString(3));
			}
			connection.close();
		}catch(Exception e){
			e.printStackTrace();
			throw new PersistenciaException(e.getMessage(), e);
		}
		return rendimentoDTO;
	}
	
	public List<Integer> quantAbas()throws PersistenciaException{
		int quantidade = 0;
		List<Integer> anos = new ArrayList<Integer>();
		try{
			Connection connection = ConexaoUtil.getInstance().getConnection();

			String sql ="select ano from tb_bolsista group by ano";
			PreparedStatement statement =  connection.prepareStatement(sql);
			ResultSet resultSet = statement.executeQuery();
			while(resultSet.next()){
				quantidade = quantidade + 1;
				anos.add(resultSet.getInt(1));
			}
		}catch(Exception e){
			e.printStackTrace();
			throw new PersistenciaException(e.getMessage(),e);
		}
		return anos;
	}
	public List<BolsistaDTO> listagemPorAno(int ano)throws PersistenciaException{
		BolsistaDTO bolsistaDTO = null;
		List<BolsistaDTO> listaRetorno = new ArrayList<BolsistaDTO>();
		try{
			Connection connection = ConexaoUtil.getInstance().getConnection();

			String sql ="select * from tb_bolsista where ano = ?;";
			PreparedStatement statement =  connection.prepareStatement(sql);
			statement.setInt(1, ano);
			ResultSet resultSet = statement.executeQuery();
			while(resultSet.next()){
				 bolsistaDTO = new BolsistaDTO();
				 bolsistaDTO.setIdBolsista(resultSet.getInt("id_bolsista"));
				 bolsistaDTO.setNome(resultSet.getString("nome"));
				 bolsistaDTO.setCpf(resultSet.getString("cpf"));
				 bolsistaDTO.setTipoRendimento(resultSet.getInt("tipo_rendimento"));
				 bolsistaDTO.setAuxilio(resultSet.getDouble("auxilio"));
				 bolsistaDTO.setAuxilioAnt(resultSet.getDouble("auxilio_ant"));
				 bolsistaDTO.setBolsa(resultSet.getDouble("bolsa"));
				 bolsistaDTO.setBolsaAnt(resultSet.getDouble("bolsa_ant"));
				 bolsistaDTO.setDiaria(resultSet.getDouble("diaria"));
				 bolsistaDTO.setDiariaAnt(resultSet.getDouble("diaria_ant"));
				 bolsistaDTO.setAno(resultSet.getInt("ano"));
				 bolsistaDTO.setSenha(resultSet.getString("senha"));
				
				 listaRetorno.add(bolsistaDTO);
			}
		}catch(Exception e){
			e.printStackTrace();
			throw new PersistenciaException(e.getMessage(),e);
		}
		return listaRetorno;
	}

}
