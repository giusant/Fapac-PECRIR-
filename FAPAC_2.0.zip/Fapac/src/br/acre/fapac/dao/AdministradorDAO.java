package br.acre.fapac.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.List;

import br.acre.fapac.dto.AdministradorDTO;
import br.acre.fapac.dto.LoginDTO;
import br.acre.fapac.exception.PersistenciaException;
import br.acre.fapac.jdbc.conexao.ConexaoUtil;

public class AdministradorDAO{


	public void inserir(AdministradorDTO administradorDTO) throws PersistenciaException {
		try{

			Connection connection =  ConexaoUtil.getInstance().getConnection();

			String sql ="INSERT INTO TB_ADMINISTRADOR(SENHA, LOGIN "
					+ " )" + " VALUES(?,?)";

			PreparedStatement Statement = connection.prepareStatement(sql);

			Statement.setString(1, administradorDTO.getSenha());
			Statement.setString(2, administradorDTO.getLogin());

			Statement.execute();
			connection.close();
		}catch(Exception e){
			e.printStackTrace();
			throw new PersistenciaException(e.getMessage(),e ) ;
		}

	}


	public void atualizar(AdministradorDTO administradorDTO) throws PersistenciaException {
		try{
			Connection connection =  ConexaoUtil.getInstance().getConnection();

			String sql =  "UPDATE TB_ADMINISTRADOR " + "SET SENHA = ? "+
					"WHERE LOGIN = ? ";

			PreparedStatement Statement = connection.prepareStatement(sql);
			Statement.setString(1, administradorDTO.getSenha());
			Statement.setString(2, administradorDTO.getLogin());

			Statement.execute();
			connection.close();

		}catch(Exception e){
			e.printStackTrace();
			throw new PersistenciaException(e.getMessage(), e);
		}	
	}


	public void deletar(String login) throws PersistenciaException {
		try{
			
			Connection connection = ConexaoUtil.getInstance().getConnection();
			String sql = "DELETE FROM TB_ADMINISTRADOR WHERE LOGIN = ?";

			PreparedStatement Statement = connection.prepareStatement(sql);
			Statement.setString(1, login);
			Statement.execute();
			connection.close();
		}catch(Exception e){
			e.printStackTrace();
			throw new PersistenciaException(e.getMessage(),e);
		}
	}
	public void deletarTudo() throws PersistenciaException {
		try{
			Connection connection = ConexaoUtil.getInstance().getConnection();
			String sql = "DELETE FROM TB_ADMINISTRADOR";

			PreparedStatement Statement = connection.prepareStatement(sql);
			Statement.execute();
			connection.close();
		}catch(Exception e){
			e.printStackTrace();
			throw new PersistenciaException(e.getMessage(),e);
		}

	}



	public List<AdministradorDTO> listarTodos() throws PersistenciaException {
		// TODO Auto-generated method stub
		return null;
	}


	public AdministradorDTO buscarPorAdm(String login) throws PersistenciaException {
		AdministradorDTO admDTO = null;
		try{
			Connection connection = ConexaoUtil.getInstance().getConnection();

			String sql ="SELECT * FROM TB_ADMINISTRADOR WHERE LOGIN = ?";
			PreparedStatement statement =  connection.prepareStatement(sql);
			statement.setString(1, login);
			ResultSet resultSet = statement.executeQuery();
			if(resultSet.next()){
				admDTO = new AdministradorDTO();
				admDTO.setSenha(resultSet.getString(1));
				admDTO.setLogin(resultSet.getString(2));
			}
			connection.close();
		}catch(Exception e){
			e.printStackTrace();
			throw new PersistenciaException(e.getMessage(), e);
		}
		return admDTO;
	}

}
