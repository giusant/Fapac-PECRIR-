package br.acre.fapac.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.List;

import br.acre.fapac.dto.LoginDTO;
import br.acre.fapac.dto.RendimentoDTO;
import br.acre.fapac.exception.PersistenciaException;
import br.acre.fapac.jdbc.conexao.ConexaoUtil;

public class LoginDAO  {


	public void inserir(LoginDTO loginDTO) throws PersistenciaException {
		try{

			Connection connection =  ConexaoUtil.getInstance().getConnection();

			String sql ="INSERT INTO TB_LOGIN(SENHA, LOGIN "
					+ " )" + " VALUES(?,?)";

			PreparedStatement Statement = connection.prepareStatement(sql);

			Statement.setString(1, loginDTO.getSenha());
			Statement.setString(2, loginDTO.getLogin());

			Statement.execute();
			connection.close();
		}catch(Exception e){
			e.printStackTrace();
			throw new PersistenciaException(e.getMessage(),e ) ;
		}


	}

	public void atualizar(LoginDTO loginDTO) throws PersistenciaException {
		try{
			Connection connection =  ConexaoUtil.getInstance().getConnection();

			String sql =  "UPDATE TB_LOGIN " + "SET LOGIN = ?, "+"SET SENHA = ? "+
					"WHERE ID_LOGIN = ? ";

			PreparedStatement Statement = connection.prepareStatement(sql);
			Statement.setString(1, loginDTO.getLogin());
			Statement.setString(2, loginDTO.getSenha());
			Statement.setInt(3, loginDTO.getIdLogin());
			Statement.execute();
			connection.close();

		}catch(Exception e){
			e.printStackTrace();
			throw new PersistenciaException(e.getMessage(), e);
		}	

	}


	public void deletar(int id) throws PersistenciaException {

		try{
		
			Connection connection = ConexaoUtil.getInstance().getConnection();
			String sql = "DELETE FROM TB_LOGIN WHERE ID_LOGIN = ?";

			PreparedStatement Statement = connection.prepareStatement(sql);
			Statement.setInt(1, id);
			Statement.execute();
			connection.close();
		}catch(Exception e){
			e.printStackTrace();
			throw new PersistenciaException(e.getMessage(),e);
		}

	}
	public void deletarTudo() throws PersistenciaException {

		try{
			Connection connection = ConexaoUtil.getInstance().getConnection();
			String sql = "DELETE FROM TB_LOGIN";

			PreparedStatement Statement = connection.prepareStatement(sql);
			Statement.execute();
			connection.close();
		}catch(Exception e){
			e.printStackTrace();
			throw new PersistenciaException(e.getMessage(),e);
		}

	}


//	public List<LoginDTO> listarTodos() throws PersistenciaException {
//		// TODO Auto-generated method stub
//		return null;
//	}
//
// nunca vou usar esse metodo!!!!
	public LoginDTO buscarPorID(String cpf) throws PersistenciaException {
		LoginDTO loginDTO = null;
		try{
			Connection connection = ConexaoUtil.getInstance().getConnection();

			String sql ="SELECT * FROM TB_LOGIN WHERE LOGIN = ?";
			PreparedStatement statement =  connection.prepareStatement(sql);
			statement.setString(1, cpf);
			ResultSet resultSet = statement.executeQuery();
			if(resultSet.next()){
				loginDTO = new LoginDTO();
				loginDTO.setLogin(resultSet.getString(1));
				loginDTO.setSenha(resultSet.getString(2));
			}
			connection.close();
		}catch(Exception e){
			e.printStackTrace();
			throw new PersistenciaException(e.getMessage(), e);
		}
		return loginDTO;
	}

}
