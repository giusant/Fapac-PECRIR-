package br.acre.fapac.bo;

import java.awt.Desktop;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;


import com.aspose.words.Orientation;
import com.aspose.words.SaveFormat;
import com.aspose.words.Section;
import com.itextpdf.text.Chunk;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Element;
import com.itextpdf.text.Font;
import com.itextpdf.text.Image;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Rectangle;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;

import br.acre.fapac.dao.BolsistaDAO;
import br.acre.fapac.dao.DocumentoDAO;
import br.acre.fapac.dto.BolsistaDTO;
import br.acre.fapac.dto.DocumentoDTO;
import br.acre.fapac.exception.LogicException;


public class DocumentoLogic {
	SimpleDateFormat dateFormatAno = new SimpleDateFormat("yyyy");
	SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
	String formato = ",##0.00";
    DecimalFormat df = new DecimalFormat(formato);
	BolsistaLogic bolsistaLogic = new BolsistaLogic();
	
	
	public void cadastar(DocumentoDTO documentoDTO) throws LogicException{
		try{
			DocumentoDAO documentoDAO = new DocumentoDAO();
			documentoDAO.inserir(documentoDTO);
		}catch(Exception e){
			throw  new LogicException(e.getMessage());
		}
	}
	
	public void deletar(String nome) throws LogicException{
		try{
			DocumentoDAO documentoDAO = new DocumentoDAO();
			documentoDAO.deletar(nome);
		}catch(Exception e){
			throw  new LogicException(e.getMessage());
		}
	}
	public void atualizar(DocumentoDTO documentoDTO) throws LogicException{
		try{
			DocumentoDAO documentoDAO = new DocumentoDAO();
			documentoDAO.atualizar(documentoDTO);;
		}catch(Exception e){
			throw  new LogicException(e.getMessage());
		}
	}
	
	public DocumentoDTO buscarDocumentoPorCpf(String nome) throws LogicException{
		DocumentoDTO documentoDTO;
		try{
			DocumentoDAO documentoDAO = new DocumentoDAO();
			 documentoDTO = documentoDAO.buscarPorCpf(nome);
		}catch(Exception e){
			throw  new LogicException(e.getMessage());
		}
		return documentoDTO;
	}
	
	
	public List<DocumentoDTO> Listagem() throws LogicException{
		List<DocumentoDTO> listaRetorno = null;
		try{
			DocumentoDAO documentoDAO = new DocumentoDAO();
			listaRetorno = documentoDAO.listarTodos();
			
		}catch(Exception e){
			e.printStackTrace();
			throw  new LogicException(e.getMessage());
		}
		return listaRetorno;
	}
	
	public File getDocumento() throws LogicException{
		List<DocumentoDTO> listaDocumento = new ArrayList<DocumentoDTO>();
		List listaRetorno = null;
		File file;
		try{
			DocumentoDAO documentoDAO = new DocumentoDAO();
			listaDocumento = documentoDAO.listarTodos();
			DocumentoDTO documentoDTO = null;
//			for(int i = 0;i< listaDocumento.size();i++){
//			
//			}
			documentoDTO = listaDocumento.get(2);
			byte[] bdoc = documentoDTO.getDocumento();
			file = new File(documentoDTO.getNomeDocumento()+".pdf");
			 FileOutputStream fos = new FileOutputStream(file);
		        fos.write(bdoc);
		        fos.flush();
		        fos.close();
			
		}catch(Exception e){
			e.printStackTrace();
			throw  new LogicException(e.getMessage());
		}
		return file;
	}
	
	
	public File gerarPDF(BolsistaDTO bolsistaDTO){
		// criaï¿½ï¿½o do documento
		Document comprovante = new Document(PageSize.A4, 20, 30, 20, 10);
		Font fonte1 = new Font(Font.FontFamily.UNDEFINED, 11,Font.BOLD);
		Font fonte2 = new Font(Font.FontFamily.UNDEFINED, 8,Font.BOLD);
		Font fonte3 = new Font(Font.FontFamily.UNDEFINED, 10);
		Font fonte4 = new Font(Font.FontFamily.UNDEFINED, 6);
		File file = null;
		OutputStream documento = null ;
		//String caminho = "C:/Users/Giuliano/Dropbox/Estágio Supervisionado/documento gerado/"+ bolsistaDTO.getCpf()+bolsistaDTO.getNome()+".pdf";
		{
			
			try {
				documento = new FileOutputStream(bolsistaDTO.getCpf()+bolsistaDTO.getNome()+".pdf");
				file =  new File(bolsistaDTO.getCpf()+bolsistaDTO.getNome()+".pdf");
				PdfWriter.getInstance(comprovante, documento);
				comprovante.open();

				// adicionando um parï¿½grafo no documento
				// comprovante.add(new Paragraph("Gerando PDF - Java"));

				//String resource = ("C:/Users/Eleandro/Dropbox/Estágio Supervisionado/Comprovante de Rendimentos/image6.jpg");
				Image img = Image.getInstance("C:/Users/Eleandro/Dropbox/Estágio Supervisionado/Comprovante de Rendimentos/image6.jpg");


				img.scaleAbsolute(50, 60);


				PdfPTable table1 = new PdfPTable(new float[] { 0.5f, 0.5f }) ;
				PdfPTable tablenested = new PdfPTable(new float[] { 0.2f, 0.8f }) ;

				PdfPTable table2 = new PdfPTable(new float[] { 0.75f, 0.25f});
				PdfPTable table3 = new PdfPTable(new float[] { 0.2f, 0.8f});
				PdfPTable table4 = new PdfPTable(1);
				PdfPTable table5 = new PdfPTable(new float[] { 0.8f, 0.2f});
				PdfPTable table6 = new PdfPTable(new float[] { 0.8f, 0.2f});
				PdfPTable table7 = new PdfPTable(new float[] { 0.8f, 0.2f});
				PdfPTable table8 = new PdfPTable(1);
				PdfPTable table9 = new PdfPTable(new float[] { 0.8f, 0.2f});



				table1.setWidthPercentage(100.0f);
				table1.setHorizontalAlignment(Element.ALIGN_JUSTIFIED);

				table2.setWidthPercentage(100.0f);
				table2.setHorizontalAlignment(Element.ALIGN_JUSTIFIED);
				table2.setSpacingBefore(2f);

				table3.setWidthPercentage(100.0f);
				table3.setHorizontalAlignment(Element.ALIGN_JUSTIFIED);
				table3.setSpacingBefore(2f);

				table4.setWidthPercentage(100.0f);
				table4.setHorizontalAlignment(Element.ALIGN_JUSTIFIED);

				table5.setWidthPercentage(100.0f);
				table5.setHorizontalAlignment(Element.ALIGN_JUSTIFIED);
				table5.setSpacingBefore(4f);

				table6.setWidthPercentage(100.0f);
				table6.setHorizontalAlignment(Element.ALIGN_JUSTIFIED);
				table6.setSpacingBefore(4f);

				table7.setWidthPercentage(100.0f);
				table7.setHorizontalAlignment(Element.ALIGN_JUSTIFIED);
				table7.setSpacingBefore(4f);

				table8.setWidthPercentage(100.0f);
				table8.setHorizontalAlignment(Element.ALIGN_JUSTIFIED);
				table8.setSpacingBefore(4f);

				table9.setWidthPercentage(100.0f);
				table9.setHorizontalAlignment(Element.ALIGN_JUSTIFIED);
				table9.setSpacingBefore(4f);
				table9.setSpacingAfter(2f);

				Paragraph p1 = new Paragraph("MINISTÉRIO DA FAZENDA", fonte1);
				Paragraph p2 = new Paragraph(new Chunk().NEWLINE);
				Paragraph p3 = new Paragraph("SECRETARIA DA RECEITA FEDERAL", fonte1);
				Paragraph p4 = new Paragraph(new Chunk().NEWLINE);
				Paragraph p5 = new Paragraph("COMPROVANTE DE RENDIMENTOS PAGOS"
						+ " E DE RETENÇÃO DE IMPOSTO DE RENDA NA FONTE ANO-CALENDÁRIO "+ bolsistaDTO.getAno() , fonte1);
				Paragraph titulo1 = new Paragraph("1. FONTE PAGADORA PESSOA JURÍDICA OU PESSOA FÍSICA", fonte1);
				Paragraph titulo2 = new Paragraph("2. PESSOA FÍSICA BENEFICIÁRIA DOS RENDIMENTOS", fonte1);
				Paragraph titulo3 = new Paragraph("3. RENDIMENTOS TRIBUTÁVEIS, DEDUÇÕES E IMPOSTO RETIDO NA FONTE             VALOR EM REAL", fonte1);
				titulo3.setAlignment(Element.ALIGN_LEFT);
				Paragraph titulo4 = new Paragraph("4. RENDIMENTOS ISENTOS E NÃO TRIBUTÁVEIS                                                             VALOR EM REAL", fonte1);
				Paragraph titulo5 = new Paragraph("5. RENDIMENTOS SUJEITOS À TRIBUTAÇÃO EXCLUSIVA (RENDIMENTO LÍQUIDO)   VALOR EM REAL", fonte1);
				Paragraph titulo6 = new Paragraph("6. INFORMAÇÕES COMPLEMENTARES", fonte1);
				Paragraph titulo7 = new Paragraph("7. RENDIMENTOS SUJEITOS À TRIBUTAÇÃO EXCLUSIVA (RENDIMENTO LÍQUIDO)", fonte1);
				Paragraph rodape = new Paragraph("Aprovado pela IN/SRF n° 120/2000", fonte4);

				Paragraph nomeempresa1 = new Paragraph("NOME EMPRESARIAL/NOME", fonte2);
				Paragraph nomeempresa2 = new Paragraph("   FUNDAÇÃO DE AMPARO À PESQUISA DO ESTADO DO ACRE - FAPAC", fonte1);
				Paragraph cnpj1 = new Paragraph("CNPJ/CPF", fonte2);
				Paragraph cnpj2 = new Paragraph("   15.449.024/0001-08", fonte1);
				Paragraph cpf1 = new Paragraph("CPF", fonte2);
				/*vai alterar*/   Paragraph cpf2 = new Paragraph("   "+ String.valueOf(bolsistaDTO.getCpf()), fonte1);
				Paragraph nomepessoa1 = new Paragraph("NOME COMPLETO", fonte2);
				/*vai alterar*/   Paragraph nomepessoa2 = new Paragraph("   " + bolsistaDTO.getNome(), fonte1);
				Paragraph rendimento1 = new Paragraph("NATUREZA DO RENDIMENTO", fonte2);

				/*vai alterar*/	  Paragraph rendimento2 = null;
				try {
					if(bolsistaLogic.buscarRendimento(bolsistaDTO).getIdRendimento() !=3){
					rendimento2 = new Paragraph("    " + bolsistaLogic.buscarRendimento(bolsistaDTO).getDescricao() , fonte1);
					}
					else {
						String parte1;
						String parte2;
						parte1 = bolsistaLogic.buscarRendimento(bolsistaDTO).getDescricao().substring(0,33);
						parte2 = bolsistaLogic.buscarRendimento(bolsistaDTO).getDescricao().substring(34,39);
						rendimento2 = new Paragraph("    " + parte1 +  "\n" + "    " + parte2 , fonte1);
					}
					
				} catch (LogicException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				Paragraph frase51 = new Paragraph("01. Total dos Rendimentos (inclusive férias)", fonte3);
				Paragraph valor00 = new Paragraph(df.format(0.0), fonte3);
		           valor00.setAlignment(Element.ALIGN_RIGHT);
				Paragraph frase53 = new Paragraph("02. Contribuição Previdenciária Oficial", fonte3);
				Paragraph frase55 = new Paragraph("03. Contribuiçãoo à  Previdência Privada e ao Fundo de Aposentadoria Programada "
						+ "Individual - FAPI", fonte3);
				Paragraph frase57 = new Paragraph("04. Pensãoo Alimentícia (informar o beneficiário no campo 6)", fonte3);
				Paragraph frase59 = new Paragraph("05. Imposto de Renda Retido", fonte3);

				Paragraph frase61 = new Paragraph("01. Parcela Isenta dos Proventos de Aposentadoria, Reserva, "
						+ "Reforma e Pensão (65 anos ou mais)", fonte3);
				 Paragraph valordiaria = new Paragraph(df.format((bolsistaDTO.getDiaria()+bolsistaDTO.getDiariaAnt())), fonte3);
		          valordiaria.setAlignment(Element.ALIGN_RIGHT);
		          Paragraph valoroutros = null;
		         
				//valor da diaria inicio
				Paragraph frase622 = new Paragraph("                            "+ String.valueOf((bolsistaDTO.getDiaria() + bolsistaDTO.getDiariaAnt())), fonte3);
				// valor diaria final
				
				// valor outros inicio
				
			
				try {
					if(bolsistaLogic.buscarRendimento(bolsistaDTO).getIdRendimento() !=3){
						if(bolsistaDTO.getAuxilio() == 0 && bolsistaDTO.getAuxilioAnt() == 0){
						 valoroutros = new Paragraph(df.format((bolsistaDTO.getBolsa() + bolsistaDTO.getBolsaAnt())), fonte3);
						}
						else{
							valoroutros = new Paragraph(df.format((bolsistaDTO.getAuxilio() + bolsistaDTO.getAuxilioAnt())), fonte3);
						}
					}
					else{
						 valoroutros = new Paragraph(df.format((bolsistaDTO.getAuxilio() + bolsistaDTO.getAuxilioAnt()))  + 
					              "\n" + "" + df.format((bolsistaDTO.getBolsa() + bolsistaDTO.getBolsaAnt())), fonte3);
					}
					 valoroutros.setAlignment(Element.ALIGN_RIGHT);
				} catch (LogicException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
				//valor outros final
				Paragraph frase63 = new Paragraph("02. Diárias e Ajudas de Custo", fonte3);
				Paragraph frase65 = new Paragraph("03. Pensão, Proventos de Aposentadoria ou Reforma por Moléstia"
						+ " Grave e Aposentadoria ou Reforma por Acidente em Serviço", fonte3);
				Paragraph frase67 = new Paragraph("04. Lucro e Dividendo Apurado a partir de 1996 pago por"
						+ " PJ (Lucro Real, Presumido ou Arbitrado)", fonte3);
				Paragraph frase69 = new Paragraph("05. Valores pagos ao Titular ou Sócio da Microempresa"
						+ " ou Empresa de Pequeno Porte, exceto Pro-labore, Alugueis ou Serviços Prestados", fonte3);
				Paragraph frase611 = new Paragraph("06. Indenização, Recisão de Contrato de Trabalho, Inclusive a título"
						+ " de PDV e acidente de trabalho", fonte3);
				
				
				/* vai alterar*/ 
				//texto  outros
				Paragraph frase613 = null;
				try {
					if(bolsistaLogic.buscarRendimento(bolsistaDTO).getIdRendimento() == 4){
						frase613 = new Paragraph("07. Outros (especificar)", fonte3);
					}
					else if(bolsistaLogic.buscarRendimento(bolsistaDTO).getIdRendimento() !=3){
						 frase613 = new Paragraph("07. Outros (especificar)" + "\n" +"     " 
					+ bolsistaLogic.buscarRendimento(bolsistaDTO).getDescricao()   , fonte3);
					}
					else{
						String parte1;
						String parte2;
						parte1 = bolsistaLogic.buscarRendimento(bolsistaDTO).getDescricao().substring(0,33);
						parte2 = bolsistaLogic.buscarRendimento(bolsistaDTO).getDescricao().substring(34,39);
						frase613 = new Paragraph("07. Outros (especificar)" + "\n" +"     "+ parte1 + "\n" + "     " + parte2 , fonte3);
					}
					
				} catch (LogicException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
				Paragraph frase71 = new Paragraph("01. Décimo Terceiro Salário"  , fonte3);
				Paragraph frase72 = new Paragraph("                            0,00", fonte3);
				Paragraph frase73 = new Paragraph("02. Outros", fonte3);

				Paragraph frase8 = new Paragraph(" " + "\n" + " "+ "\n" + " " + "\n" + " " + "\n" + 
						" " + "\n" + " " + "\n" + " " + "\n" + " ");

				Paragraph nome91 = new Paragraph("NOME COMPLETO", fonte2);
				Paragraph nome92 = new Paragraph("   "+ bolsistaDTO.getNome(), fonte1);
				Paragraph data1 = new Paragraph("DATA", fonte2);
				Paragraph data2 = new Paragraph("     " + dateFormat.format(new java.util.Date()), fonte1);




				//Alinha o parï¿½grafo no centro
				p5.setAlignment(Element.ALIGN_CENTER);
				//Configura o espaï¿½amento entre as linhas
				p5.setLeading(20f);

				PdfPCell header1 = new PdfPCell();
				header1.setBorder(Rectangle.NO_BORDER);
				PdfPCell himg = new PdfPCell(img);
				himg.setBorder(Rectangle.NO_BORDER);
				PdfPCell header2 = new PdfPCell();
				PdfPCell header21 = new PdfPCell();
				PdfPCell header22 = new PdfPCell();
				PdfPCell header31 = new PdfPCell();
				PdfPCell header32 = new PdfPCell();
				PdfPCell header91 = new PdfPCell();
				PdfPCell header92 = new PdfPCell();
				PdfPCell header4 = new PdfPCell();
				PdfPCell outros = new PdfPCell();
                PdfPCell diarias = new PdfPCell();
                PdfPCell valorzero = new PdfPCell();

				header1.addElement(p1);
				header1.addElement(p2);
				header1.addElement(p3);
				header1.addElement(p4);

				header2.addElement(p5);

				header21.addElement(nomeempresa1);
				header21.addElement(nomeempresa2);
				header22.addElement(cnpj1);
				header22.addElement(cnpj2);

				header31.addElement(cpf1);
				header31.addElement(cpf2);

				header32.addElement(nomepessoa1);
				header32.addElement(nomepessoa2);


				header4.addElement(rendimento1);
				header4.addElement(rendimento2);

				header91.addElement(nome91);
				header91.addElement(nome92);

				header92.addElement(data1);
				header92.addElement(data2);

				diarias.addElement(valordiaria);
				outros.addElement(valoroutros);
				valorzero.addElement(valor00);

				tablenested.addCell(himg);
				tablenested.addCell(header1);

				table1.addCell(tablenested);	
				table1.addCell(header2);

				table2.addCell(header21);
				table2.addCell(header22);

				table3.addCell(header31);
				table3.addCell(header32);

				table4.addCell(header4);

				table5.addCell(frase51);
                table5.addCell(valorzero);
                table5.addCell(frase53);
                table5.addCell(valorzero);
                table5.addCell(frase55);
                table5.addCell(valorzero);
                table5.addCell(frase57);
                table5.addCell(valorzero);
                table5.addCell(frase59);
                table5.addCell(valorzero);

                table6.addCell(frase61);
                table6.addCell(valorzero);
                table6.addCell(frase63);
                table6.addCell(diarias);
                table6.addCell(frase65);
                table6.addCell(valorzero);
                table6.addCell(frase67);
                table6.addCell(valorzero);
                table6.addCell(frase69);
                table6.addCell(valorzero);
                table6.addCell(frase611);
                table6.addCell(valorzero);
                table6.addCell(frase613);
                table6.addCell(outros);
                
                table7.addCell(frase71);
                table7.addCell(valorzero);
                table7.addCell(frase73);
                table7.addCell(valorzero);
				table8.addCell(frase8);

				table9.addCell(header91);
				table9.addCell(header92);

				comprovante.add(table1);
				comprovante.add(titulo1);
				comprovante.add(table2);
				comprovante.add(titulo2);
				comprovante.add(table3);
				comprovante.add(table4);
				comprovante.add(titulo3);
				comprovante.add(table5);	
				comprovante.add(titulo4);
				comprovante.add(table6);
				comprovante.add(titulo5);
				comprovante.add(table7);
				comprovante.add(titulo6);
				comprovante.add(table8);
				comprovante.add(titulo7);
				comprovante.add(table9);
				comprovante.add(rodape);

			}
			catch(DocumentException de) {
				System.err.println(de.getMessage());
			}
			catch(IOException ioe) {
				System.err.println(ioe.getMessage());
			}

			comprovante.close();
		}
		return file;   
	}

	public void salvarPDFs(){
		BolsistaLogic bolsistaLogic = new BolsistaLogic();
		BolsistaDTO bolsistaDTO = new BolsistaDTO();
		List<BolsistaDTO> listaBolsistas = new ArrayList<BolsistaDTO>();
		DocumentoDTO documentoDTO = new DocumentoDTO();

		try {
			listaBolsistas =  bolsistaLogic.Listagem();
			File file;	
			for(int i = 0; i < listaBolsistas.size();i++){
				if(  false == bolsistaLogic.existeDocumento(String.valueOf(listaBolsistas.get(i).getCpf()+listaBolsistas.get(i).getNome()+listaBolsistas.get(i).getAno()))){
					bolsistaDTO = listaBolsistas.get(i);
					//caminho = gerarPDF(bolsistaDTO);
					//file = new File(caminho);
					file = gerarPDF(bolsistaDTO);
					documentoDTO.setNomeDocumento(String.valueOf(bolsistaDTO.getCpf()+bolsistaDTO.getNome()+bolsistaDTO.getAno()));
					documentoDTO.setAno(dateFormat.parse(dateFormat.format(new java.util.Date())));
					byte[] doc = new byte[(int)(file).length()];
					java.io.DataInputStream is = new java.io.DataInputStream( new FileInputStream(file));
					is.readFully(doc);
					is.close();
					documentoDTO.setDocumento(doc);

					Date dataAtual = new java.util.Date();
					int dataBolsista = bolsistaDTO.getAno();
					String a,b;
					a = String.valueOf(dataBolsista);
					b = dateFormatAno.format(dataAtual);
					boolean aux;
					aux = a.equals(b);
					
						cadastar(documentoDTO);
					
				}


			}
		
		
		
		} catch (LogicException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	public void salvarPDF(BolsistaDTO bolsistaDTO){
		BolsistaLogic bolsistaLogic = new BolsistaLogic();
		
		DocumentoDTO documentoDTO = new DocumentoDTO();
		
		try {
	
		File file;	
		
			//caminho = gerarPDF(bolsistaDTO);
			//file = new File(caminho);
			file = gerarPDF(bolsistaDTO);
			documentoDTO.setNomeDocumento(String.valueOf(bolsistaDTO.getCpf()+bolsistaDTO.getNome()+bolsistaDTO.getAno()));
			documentoDTO.setAno(dateFormat.parse(dateFormat.format(new java.util.Date())));
			byte[] doc = new byte[(int)(file).length()];
			java.io.DataInputStream is = new java.io.DataInputStream( new FileInputStream(file));
			is.readFully(doc);
			is.close();
			documentoDTO.setDocumento(doc);
			
//			Date dataAtual = new java.util.Date();
//			int dataBolsista = bolsistaDTO.getAno();
//			String a,b;
//			a = String.valueOf(dataBolsista);
//			b = dateFormatAno.format(dataAtual);
//			boolean aux;
//			aux = a.equals(b);
//			if(aux){
			cadastar(documentoDTO);
//			}
			
			
		
		
		
		
		} catch (LogicException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	public int saberRendimentoPorValor(double auxilio, double auxilioAnt , double bolsa, double bolsaAnt, double diaria, double diariaAnt){
		if((auxilio == 0) && (auxilioAnt == 0) && (bolsa == 0) && (bolsaAnt == 0))
			return 4;	
		if((auxilio != 0 || auxilioAnt != 0  )  &&	(bolsa != 0 || bolsaAnt != 0)){
			return 3;
		}
		if((auxilio != 0  ||  auxilioAnt != 0) && (bolsa == 0  ||  bolsaAnt == 0)){
			return 1;
		}
		if((bolsa != 0  ||  bolsaAnt != 0) && (auxilio == 0  ||  auxilioAnt == 0) ){
			return 2;
		}
		return 0;
	}



	
}
