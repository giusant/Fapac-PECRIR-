package br.acre.fapac.bo;

import br.acre.fapac.dao.LoginDAO;
import br.acre.fapac.dto.LoginDTO;
import br.acre.fapac.exception.LogicException;

public class LoginLogic {
	public void cadastar(LoginDTO loginDTO) throws LogicException{
		try{
			LoginDAO loginDAO = new LoginDAO();
			loginDAO.inserir(loginDTO);
		}catch(Exception e){
			throw  new LogicException(e.getMessage());
		}
	}

	public void deletarTudo() throws LogicException{
		try{
			LoginDAO LoginDAO = new LoginDAO();
			LoginDAO.deletarTudo();
		}catch(Exception e){
			throw  new LogicException(e.getMessage());
		}
	}
	public void deletar(int cpf) throws LogicException{
		try{
			LoginDAO loginDAO = new LoginDAO();
			loginDAO.deletar(cpf);
		}catch(Exception e){
			throw  new LogicException(e.getMessage());
		}
	}
	public void atualizar(LoginDTO loginDTO) throws LogicException{
		try{
			LoginDAO loginDAO = new LoginDAO();
			loginDAO.atualizar(loginDTO);
		}catch(Exception e){
			throw new LogicException(e.getMessage());
		}
	}
	public LoginDTO buscarLogin(String cpf) throws LogicException{
		LoginDTO loginDTO;
		try{
			LoginDAO loginDAO = new LoginDAO();
			  loginDTO = loginDAO.buscarPorID(cpf);
		}catch(Exception e){
			throw new LogicException(e.getMessage());
		}
		return loginDTO;
	}

}
