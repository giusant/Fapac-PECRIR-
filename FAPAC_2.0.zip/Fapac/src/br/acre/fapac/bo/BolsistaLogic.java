package br.acre.fapac.bo;

import java.awt.Desktop;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import br.acre.fapac.dao.BolsistaDAO;
import br.acre.fapac.dao.DocumentoDAO;
import br.acre.fapac.dto.BolsistaDTO;
import br.acre.fapac.dto.DocumentoDTO;
import br.acre.fapac.dto.RendimentoDTO;
import br.acre.fapac.exception.LogicException;
import br.acre.fapac.exception.PersistenciaException;
import br.acre.fapac.exception.ValidacaoException;



public class BolsistaLogic {
	SimpleDateFormat dateFormatAno = new SimpleDateFormat("yyyy");
	public void cadastar(BolsistaDTO bolsistaDTO) throws LogicException, PersistenciaException{
	
			BolsistaDAO bolsistaDAO = new BolsistaDAO();
			validarCPF(bolsistaDTO);
			bolsistaDAO.inserir(bolsistaDTO);
	
	
		
	}
	public void cadastarUmBolsista(BolsistaDTO bolsistaDTO) throws LogicException, PersistenciaException{
		
			DocumentoLogic documentoLogic = new DocumentoLogic();
			BolsistaDAO bolsistaDAO = new BolsistaDAO();
			validarCPF(bolsistaDTO);
			bolsistaDAO.inserir(bolsistaDTO);
		
			
			documentoLogic.salvarPDF(bolsistaDTO);
	
	}

	public void validarCPF(BolsistaDTO bolsistaDTO) throws LogicException, PersistenciaException {
		BolsistaLogic bolsistaLogic = new BolsistaLogic();
		 BolsistaDTO bolsistasBuscado = bolsistaLogic.buscarBolsista(bolsistaDTO.getCpf(), bolsistaDTO.getAno());
		if((bolsistasBuscado != null)
			&& bolsistaDTO.getAno() == bolsistasBuscado.getAno()) {
			throw new LogicException("O Bolsista " + bolsistaDTO.getNome() + 
					" j� est� cadastrado no ano de " + bolsistaDTO.getAno());
		}
		
	}
	public void deletarTudo() throws LogicException{
		try{
			BolsistaDAO bolsistaDAO = new BolsistaDAO();
			bolsistaDAO.deletartudo();
		}catch(Exception e){
			throw  new LogicException(e.getMessage());
		}
	}
	public void deletar(BolsistaDTO bolsistaDTO, String nome) throws LogicException{
		try{
			DocumentoLogic documentoLogic = new DocumentoLogic();
		
			BolsistaDAO bolsistaDAO = new BolsistaDAO();
			bolsistaDAO.deletar(bolsistaDTO.getCpf(), bolsistaDTO.getAno());
			documentoLogic.deletar(nome);
	
		}catch(Exception e){
			throw  new LogicException(e.getMessage());
		}
	}
	public void atualizar(BolsistaDTO bolsistaDTO,String nome) throws LogicException{
		try{

			DocumentoLogic documentoLogic = new DocumentoLogic();
			BolsistaDAO bolsistaDAO = new BolsistaDAO();
			bolsistaDAO.atualizar(bolsistaDTO);
			documentoLogic.deletar(nome);
			documentoLogic.salvarPDF(bolsistaDTO);

			
		}catch(Exception e){
			throw new LogicException(e.getMessage());
		}
	}
	public BolsistaDTO buscarBolsista(String cpf, int ano) throws LogicException, PersistenciaException{
		BolsistaDTO bolsistaDTO = null;
	
			BolsistaDAO bolsistaDAO = new BolsistaDAO();
			if(bolsistaDAO.buscarBolsistaPorCpfAno(cpf, ano) != null)  
			bolsistaDTO = bolsistaDAO.buscarBolsistaPorCpfAno(cpf, ano);
			//else
				//throw new LogicException("Bolsista n�o encontrado!");

		return bolsistaDTO;
	}
	public BolsistaDTO buscarBolsista(int id) throws LogicException, PersistenciaException{
		BolsistaDTO bolsistaDTO = null;

		BolsistaDAO bolsistaDAO = new BolsistaDAO();
		if(bolsistaDAO.buscarBolsistaPorId(id) != null)  
			bolsistaDTO = bolsistaDAO.buscarBolsistaPorId(id);
		//else
			//throw new LogicException("Bolsista n�o encontrado!");

		return bolsistaDTO;
	}

	
	
	public List<BolsistaDTO> Listagem() throws LogicException{
		List<BolsistaDTO> listaRetorno;
		try{
			BolsistaDAO bolsistaDAO = new BolsistaDAO();
			  listaRetorno = bolsistaDAO.listarTodos();
		}catch(Exception e){
			throw  new LogicException(e.getMessage());
		}
		return listaRetorno;
	}
	
	@SuppressWarnings("unchecked")
	public void lerPlanila(File file) throws PersistenciaException, LogicException, IOException, FileNotFoundException, InvalidFormatException{
		  FileInputStream fisPlanilha = null;
		  BolsistaDTO bolsistaDTO;
		  List linha = new ArrayList();
	    
	        	// caminho completo do arquivo
	           // File file = new File("C:\\Users\\Giuliano\\Dropbox\\Est�gio Supervisionado\\TestJXL.xlsx");
	            fisPlanilha = new FileInputStream(file);

	            //cria um workbook = planilha toda com todas as abas
	            XSSFWorkbook workbook = new XSSFWorkbook(fisPlanilha);

	            //recuperamos apenas a primeira aba ou primeira planilha
	            XSSFSheet sheet = workbook.getSheetAt(0);

	            //retorna todas as linhas da planilha 0 (aba 1)
	            Iterator<Row> rowIterator = sheet.iterator();
	             rowIterator.next();
	            //varre todas as linhas da planilha 0
	            while (rowIterator.hasNext()) {
	            	
	            	
	                //recebe cada linha da planilha
	                Row row = rowIterator.next();
	                

	                //pegamos todas as celulas desta linha
	                Iterator<Cell> cellIterator = row.iterator();

	                //varremos todas as celulas da linha atual
	                bolsistaDTO = new BolsistaDTO();
	                while (cellIterator.hasNext()) {
	                	bolsistaDTO = new BolsistaDTO();
	                    //criamos uma celula
	                    Cell cell = cellIterator.next();
	                   
	                    
	                    
	                    switch (cell.getCellType()) {

	                        case Cell.CELL_TYPE_STRING:
	                            System.out.println("TIPO STRING: " + cell.getStringCellValue());
	                            linha.add(cell.getStringCellValue());
	                            break;

	                        case Cell.CELL_TYPE_NUMERIC:
	                            System.out.println("TIPO NUMERICO: " + cell.getNumericCellValue());
	                            linha.add(cell.getNumericCellValue());
	                            break;
	                            
	                        case Cell.CELL_TYPE_FORMULA:
	                            System.out.println("TIPO FORMULA: " + cell.getCellFormula());
	                    }
	                    
	      
	                   
	                }
	                if(!linha.isEmpty()){
	                 int tipoRendimento = saberRendimento(linha);
	                bolsistaDTO.setNome(linha.get(0).toString());
                    bolsistaDTO.setCpf(linha.get(1).toString());
                    bolsistaDTO.setTipoRendimento(tipoRendimento);
                    bolsistaDTO.setAuxilio(Double.parseDouble(linha.get(3).toString()));
                    bolsistaDTO.setAuxilioAnt(Double.parseDouble(linha.get(4).toString()));
                    bolsistaDTO.setBolsa(Double.parseDouble(linha.get(5).toString()));
                    bolsistaDTO.setBolsaAnt(Double.parseDouble(linha.get(6).toString()));
                    bolsistaDTO.setDiaria(Double.parseDouble(linha.get(7).toString()));
                    bolsistaDTO.setDiariaAnt(Double.parseDouble(linha.get(8).toString()));
                    bolsistaDTO.setSenha(linha.get(1).toString().substring(0,4));
                    bolsistaDTO.setAno((int)Double.parseDouble(linha.get(10).toString()));
          
                    	validarCPF(bolsistaDTO);
						cadastar(bolsistaDTO);
					
	                }
                 
                    linha.clear();
                 
                  
          
	            }
	            fisPlanilha.close();

	  
	        

	    }
	
	@SuppressWarnings("unchecked")
	public void lerPlanilaValidacao(File file) throws PersistenciaException, LogicException, IOException{
		  FileInputStream fisPlanilha = null;
		  BolsistaDTO bolsistaDTO;
		  List linha = new ArrayList();
	    
	        	// caminho completo do arquivo
	           // File file = new File("C:\\Users\\Giuliano\\Dropbox\\Est�gio Supervisionado\\TestJXL.xlsx");
	            fisPlanilha = new FileInputStream(file);

	            //cria um workbook = planilha toda com todas as abas
	            XSSFWorkbook workbook = new XSSFWorkbook(fisPlanilha);

	            //recuperamos apenas a primeira aba ou primeira planilha
	            XSSFSheet sheet = workbook.getSheetAt(0);

	            //retorna todas as linhas da planilha 0 (aba 1)
	            Iterator<Row> rowIterator = sheet.iterator();
	             rowIterator.next();
	            //varre todas as linhas da planilha 0
	            while (rowIterator.hasNext()) {
	            	
	            	
	                //recebe cada linha da planilha
	                Row row = rowIterator.next();
	                

	                //pegamos todas as celulas desta linha
	                Iterator<Cell> cellIterator = row.iterator();

	                //varremos todas as celulas da linha atual
	                bolsistaDTO = new BolsistaDTO();
	                while (cellIterator.hasNext()) {
	                	bolsistaDTO = new BolsistaDTO();
	                    //criamos uma celula
	                    Cell cell = cellIterator.next();
	                   
	                    
	                    
	                    switch (cell.getCellType()) {

	                        case Cell.CELL_TYPE_STRING:
	                            System.out.println("TIPO STRING: " + cell.getStringCellValue());
	                            linha.add(cell.getStringCellValue());
	                            break;

	                        case Cell.CELL_TYPE_NUMERIC:
	                            System.out.println("TIPO NUMERICO: " + cell.getNumericCellValue());
	                            linha.add(cell.getNumericCellValue());
	                            break;
	                            
	                        case Cell.CELL_TYPE_FORMULA:
	                            System.out.println("TIPO FORMULA: " + cell.getCellFormula());
	                    }
	                    
	      
	                   
	                }
	                if(!linha.isEmpty()){
	                 int tipoRendimento = saberRendimento(linha);
	                bolsistaDTO.setNome(linha.get(0).toString());
                    bolsistaDTO.setCpf(linha.get(1).toString());
                    bolsistaDTO.setTipoRendimento(tipoRendimento);
                    bolsistaDTO.setAuxilio(Double.parseDouble(linha.get(3).toString()));
                    bolsistaDTO.setAuxilioAnt(Double.parseDouble(linha.get(4).toString()));
                    bolsistaDTO.setBolsa(Double.parseDouble(linha.get(5).toString()));
                    bolsistaDTO.setBolsaAnt(Double.parseDouble(linha.get(6).toString()));
                    bolsistaDTO.setDiaria(Double.parseDouble(linha.get(7).toString()));
                    bolsistaDTO.setDiariaAnt(Double.parseDouble(linha.get(8).toString()));
                    bolsistaDTO.setSenha(linha.get(1).toString().substring(0,4));
                    bolsistaDTO.setAno((int)Double.parseDouble(linha.get(10).toString()));
          
                    	validarCPF(bolsistaDTO);
						
					
	                }
                 
                    linha.clear();
                 
                  
          
	            }
	            fisPlanilha.close();

	  
	        

	    }
	//saber qual o tipo da natureza de rendimento, atras do valores da planilha.
	public int saberRendimento(List linha){
		if((Double.parseDouble(linha.get(3).toString()) == 0) && (Double.parseDouble(linha.get(4).toString()) == 0)
				&& (Double.parseDouble(linha.get(5).toString()) == 0) && (Double.parseDouble(linha.get(6).toString()) == 0))
			return 4;	
		if(((Double.parseDouble(linha.get(3).toString()) != 0 || Double.parseDouble(linha.get(4).toString()) != 0  )  &&
				(Double.parseDouble(linha.get(5).toString()) != 0 || Double.parseDouble(linha.get(6).toString()) != 0))){
			return 3;
		}
		if(((Double.parseDouble(linha.get(3).toString()) != 0)  ||  (Double.parseDouble(linha.get(4).toString()) != 0)) 
				&& ((Double.parseDouble(linha.get(5).toString()) == 0)  ||  (Double.parseDouble(linha.get(6).toString()) == 0))         ){
			return 1;
		}
		if(((Double.parseDouble(linha.get(5).toString()) != 0)  ||  (Double.parseDouble(linha.get(6).toString()) != 0)) 
				&& ((Double.parseDouble(linha.get(3).toString()) == 0)  ||  (Double.parseDouble(linha.get(4).toString()) == 0)) ){
			return 2;
		}
		return 0;
	}
	public int saberRendimentoPorValor(double auxilio, double auxilioAnt , double bolsa, double bolsaAnt, double diaria, double diariaAnt){
		if((auxilio == 0) && (auxilioAnt == 0) && (bolsa == 0) && (bolsaAnt == 0))
			return 4;	
		if((auxilio != 0 || auxilioAnt != 0  )  &&
				bolsa != 0 || bolsaAnt != 0){
			return 3;
		}
		if((auxilio != 0)  ||  (auxilioAnt != 0) 
				&& (bolsa == 0)  ||  (bolsaAnt == 0)){
			return 1;
		}
		if((bolsa != 0)  ||  (bolsaAnt != 0) 
				&& (auxilio == 0)  ||  (auxilioAnt == 0) ){
			return 2;
		}
		return 0;
	}
	
	public RendimentoDTO buscarRendimento(BolsistaDTO bolsistaDTO) throws LogicException{
		RendimentoDTO rendimento = null;
		try{
			BolsistaDAO bolsistaDAO = new BolsistaDAO();
			 rendimento = bolsistaDAO.buscarRendimento(bolsistaDTO.getTipoRendimento());
		}catch(Exception e){
			throw  new LogicException(e.getMessage());
		}
		return rendimento;
	}
	public File getDocumento(String nome) throws LogicException{
		List<DocumentoDTO> listaDocumento = new ArrayList<DocumentoDTO>();
		List listaRetorno = null;
		File file;
		try{
			DocumentoDAO documentoDAO = new DocumentoDAO();
			listaDocumento = documentoDAO.listarTodos();
			DocumentoDTO documentoDTO = null;
			byte[] bdoc = null;
			for(int i = 0;i< listaDocumento.size();i++){
				if(nome.equalsIgnoreCase(listaDocumento.get(i).getNomeDocumento())){
					documentoDTO = listaDocumento.get(i);
					bdoc = documentoDTO.getDocumento();
					i=listaDocumento.size() + 1;
				}
			}
			//documentoDTO = listaDocumento.get(2);
		
			file = new File(documentoDTO.getNomeDocumento()+".pdf");
			 FileOutputStream fos = new FileOutputStream(file);
		        fos.write(bdoc);
		        fos.flush();
		        fos.close();
			
		}catch(Exception e){
			e.printStackTrace();
			throw  new LogicException(e.getMessage());
		}
		return file;
	}
	public boolean existeDocumento(String nome) throws LogicException{
		List<DocumentoDTO> listaDocumento = new ArrayList<DocumentoDTO>();
		List listaRetorno = null;
		File file;
		try{
			DocumentoDAO documentoDAO = new DocumentoDAO();
			listaDocumento = documentoDAO.listarTodos();
			DocumentoDTO documentoDTO = null;
			byte[] bdoc = null;
			for(int i = 0;i< listaDocumento.size();i++){
				if(nome.equalsIgnoreCase(listaDocumento.get(i).getNomeDocumento())){
					documentoDTO = listaDocumento.get(i);
					bdoc = documentoDTO.getDocumento();
					i=listaDocumento.size() + 1;
					return true;
				}
			}
			//documentoDTO = listaDocumento.get(2);
		
//			file = new File(documentoDTO.getNomeDocumento()+".pdf");
//			 FileOutputStream fos = new FileOutputStream(file);
//		        fos.write(bdoc);
//		        fos.flush();
//		        fos.close();
			
		}catch(Exception e){
			e.printStackTrace();
			throw  new LogicException(e.getMessage());
		}
		return false;
	}
	
	public static void abrirDocumento(BolsistaDTO BolsistaDTO) throws LogicException, IOException{
		BolsistaLogic bolsistaLogic = new BolsistaLogic();	
		File doc;
		doc = bolsistaLogic.getDocumento(String.valueOf(BolsistaDTO.getCpf()+BolsistaDTO.getNome()+BolsistaDTO.getAno()));
		Desktop.getDesktop().open(doc);
	}
	public boolean validaLogin(String cpf, String senha) throws LogicException, NumberFormatException, PersistenciaException, ValidacaoException{
		BolsistaDTO bolsistaDTO;
		BolsistaDAO bolsistaDAO = new BolsistaDAO();
		if(cpf ==  null ||  "".equals(cpf)){
			throw new ValidacaoException("O campo CPF � obrigat�rio!");
		}else if(cpf.length() != 11 ){
			throw new ValidacaoException("O campo CPF possui 11 carecteres!");
		}else {

			char[] digitos = cpf.toCharArray();
			for(char digito : digitos){
				if(!Character.isDigit(digito)){
					throw new ValidacaoException("O campo CPF � somente num�rico!");
				}
			}
		}
			
			if(senha ==  null ||  "".equals(senha)){
				throw new ValidacaoException("O campo Senha � obrigat�rio!");
			}
			if(bolsistaDAO.buscarBolsistaPorCpfAno(cpf, Integer.parseInt(dateFormatAno.format(new java.util.Date()) ) -1) != null)	
			bolsistaDTO = bolsistaDAO.buscarBolsistaPorCpfAno(cpf, Integer.parseInt(dateFormatAno.format(new java.util.Date()) ) -1);
			else
				throw new LogicException("O usu�rio n�o existe!");
			
			if(bolsistaDTO.getSenha().equalsIgnoreCase(senha)){
				return true;
			}
			else {
				throw new LogicException("Senha incorreta");
			}
	}

	public List<Integer> quantidadeAbas() throws LogicException{
		BolsistaDAO bolsistaDAO = new BolsistaDAO();
		List<Integer> anos = new ArrayList<Integer>();
		try {
			anos = bolsistaDAO.quantAbas();
		} catch (PersistenciaException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return anos;
	}
	// lista de bolsistas de um deterniandao ano
	public List<BolsistaDTO> listagemPorAno(int ano) throws LogicException{
		BolsistaDAO bolsistaDAO = new BolsistaDAO();
		List<BolsistaDTO> anos = new ArrayList<BolsistaDTO>();
		try {
			anos = bolsistaDAO.listagemPorAno(ano);
		} catch (PersistenciaException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return anos;
	}

	public boolean validaCamposIncluir(String cpf, String nome) throws LogicException, NumberFormatException, PersistenciaException, ValidacaoException{
	
		if(cpf ==  null ||  "".equals(cpf)){
			throw new ValidacaoException("O campo CPF � obrigat�rio!");
		}else if(cpf.length() != 11 ){
			throw new ValidacaoException("O campo CPF possui 11 carecteres!");
		}else {

			char[] digitos = cpf.toCharArray();
			for(char digito : digitos){
				if(!Character.isDigit(digito)){
					throw new ValidacaoException("O campo CPF � somente num�rico!");
				}
			}
		}

		if(nome ==  null ||  "".equals(nome)){
			throw new ValidacaoException("O campo Nome � obrigat�rio!");
		}
		
		return true;
	}
	public String validasAuxilio(String auxilio) throws LogicException, NumberFormatException, PersistenciaException, ValidacaoException{

		if(auxilio ==  null ||  "".equals(auxilio)){
			auxilio  = "0";
		}
		else{
			try{
				Double.parseDouble(auxilio);
			}catch(Exception e){
				throw new ValidacaoException("O campo 'Aux�lio ao pesquisador' � somente num�rico!");
			}
		}
//		else {
//			char[] digitos = auxilio.toCharArray();
//			for(char digito : digitos){
//				if(!Character.isDigit(digito)){
//					throw new ValidacaoException("O campo 'Aux�lio ao pesquisador' � somente num�rico!");
//				}
//			}
//		}
		return auxilio;
	}
	public void validaAno(String ano) throws LogicException, NumberFormatException, PersistenciaException, ValidacaoException{

		if(ano ==  null ||  "".equals(ano)){
			throw new ValidacaoException("O campo 'Ano/Per�odo' � obrigat�rio!");
		}else {

			char[] digitos = ano.toCharArray();
			for(char digito : digitos){
				if(!Character.isDigit(digito)){
					System.out.println("Entrei");
					throw new LogicException("O campo 'Ano/Per�odo' � somente num�rico!");
				}
			}
		}
	}
	public String validasAuxilioAnterior(String auxilioAnterior) throws LogicException, NumberFormatException, PersistenciaException, ValidacaoException{

		if(auxilioAnterior ==  null ||  "".equals(auxilioAnterior)){
			auxilioAnterior  = "0";
		}
		else{
			try{
				Double.parseDouble(auxilioAnterior);
			}catch(Exception e){
				throw new ValidacaoException("O campo 'Ano anterior' referente a 'Aux�lio ao pesquisador' � somente num�rico!");
			}
		}
//		else {
//			char[] digitos = auxilioAnterior.toCharArray();
//			for(char digito : digitos){
//				if(!Character.isDigit(digito)){
//					throw new ValidacaoException("O campo 'Ano anterior' referente a 'Aux�lio ao pesquisador' � somente num�rico!");
//				}
//			}
//		}
		return auxilioAnterior;
	}
	public String validasBolsa(String bolsa) throws LogicException, NumberFormatException, PersistenciaException, ValidacaoException{

		if(bolsa ==  null ||  "".equals(bolsa)){
			bolsa  = "0";
		}
		else{
			try{
				Double.parseDouble(bolsa);
			}catch(Exception e){
				throw new ValidacaoException("O campo 'Bolsa' � somente num�rico!");
			}
		}
//		else {
//			char[] digitos = bolsa.toCharArray();
//			for(char digito : digitos){
//				if(!Character.isDigit(digito)){
//					throw new ValidacaoException("O campo 'Bolsa' � somente num�rico!");
//				}
//			}
//		}
		return bolsa;
	}
	public String validasBolsaAnterior(String bolsaAnterior) throws LogicException, NumberFormatException, PersistenciaException, ValidacaoException{

		if(bolsaAnterior ==  null ||  "".equals(bolsaAnterior)){
			bolsaAnterior  = "0";
		}
		else{
			try{
				Double.parseDouble(bolsaAnterior);
			}catch(Exception e){
				throw new ValidacaoException("O campo 'Ano anterior' referente 'Bolsa' � somente num�rico!");
			}
		}
//		else {
//			char[] digitos = bolsaAnterior.toCharArray();
//			for(char digito : digitos){
//				if(!Character.isDigit(digito)){
//					throw new ValidacaoException("O campo 'Ano anterior' referente a 'bolsa' � somente num�rico!");
//				}
//			}
//		}
		return bolsaAnterior;
	}
	public String validasDiaria(String diaria) throws LogicException, NumberFormatException, PersistenciaException, ValidacaoException{

		if(diaria ==  null ||  "".equals(diaria)){
			diaria  = "0";
		}
		else{
			try{
				Double.parseDouble(diaria);
			}catch(Exception e){
				throw new ValidacaoException("O campo 'Di�ria' � somente num�rico!");
			}
		}
//		else {
//			char[] digitos = diaria.toCharArray();
//			for(char digito : digitos){
//				if(!Character.isDigit(digito)){
//					throw new ValidacaoException("O campo 'Di�ria' � somente num�rico!");
//				}
//			}
//		}
		return diaria;
	}
	public String validasDiariaAnterior(String diariaAnterior) throws LogicException, NumberFormatException, PersistenciaException, ValidacaoException{

		if(diariaAnterior ==  null ||  "".equals(diariaAnterior)){
			diariaAnterior  = "0";
		}
		else{
			try{
				Double.parseDouble(diariaAnterior);
			}catch(Exception e){
				throw new ValidacaoException("O campo 'Ano anterior' referente a 'Di�ria' � somente num�rico!");
			}
		}
//		else {
//			char[] digitos = diariaAnterior.toCharArray();
//			for(char digito : digitos){
//				if(!Character.isDigit(digito)){
//					throw new ValidacaoException("O campo 'Ano anterior' referente a 'Di�ria' � somente num�rico!");
//				}
//			}
//		}
		return diariaAnterior;
	}
}