package br.acre.fapac.bo;

import br.acre.fapac.dao.AdministradorDAO;
import br.acre.fapac.dto.AdministradorDTO;
import br.acre.fapac.exception.LogicException;
import br.acre.fapac.exception.PersistenciaException;

public class AdministradorLogic {
	public void cadastar(AdministradorDTO administradorDTO) throws LogicException{
		try{
			AdministradorDAO admDAO = new AdministradorDAO();
			admDAO.inserir(administradorDTO);
		}catch(Exception e){
			throw  new LogicException(e.getMessage());
		}
	}

	public void deletarTudo() throws LogicException{
		try{
			AdministradorDAO admDAO = new AdministradorDAO();
			admDAO.deletarTudo();
		}catch(Exception e){
			throw  new LogicException(e.getMessage());
		}
	}
	public void deletar(String login) throws LogicException{
		try{
			AdministradorDAO admDAO = new AdministradorDAO();
			admDAO.deletar(login);
		}catch(Exception e){
			throw  new LogicException(e.getMessage());
		}
	}
	public void atualizar(AdministradorDTO admDTO) throws LogicException{
		try{
			AdministradorDAO admDAO = new AdministradorDAO();
			admDAO.atualizar(admDTO);
		}catch(Exception e){
			throw new LogicException(e.getMessage());
		}
	}
	public AdministradorDTO buscarAdm( String login) throws LogicException, PersistenciaException{
		AdministradorDTO admDTO;
		
			AdministradorDAO admDAO = new AdministradorDAO();
			  
			if(admDAO.buscarPorAdm(login) != null)
				admDTO = admDAO.buscarPorAdm(login);
			else
			throw new LogicException("Usu�rio e/ou Senha incorreto.");
		
		return admDTO;
	}
	public boolean validaAdministrador(String login, String senha) throws LogicException, PersistenciaException{
		AdministradorDTO admDTO;
	
			admDTO = buscarAdm(login);
			if(admDTO.getSenha().equals(senha)){
				return true;
			}
			else {
				throw new LogicException("Usu�rio e/ou Senha incorreto.");
			}
		
	}
	public boolean validaRedefinirSenha(String senhaNova, String confirmaSenha) throws LogicException{
		AdministradorDTO admDTO;
			
			if(confirmaSenha.equals(senhaNova)){
				
				return true;
			}
			else {
				throw new LogicException("Senhas incomp�tives");
			}
		
	}
}
